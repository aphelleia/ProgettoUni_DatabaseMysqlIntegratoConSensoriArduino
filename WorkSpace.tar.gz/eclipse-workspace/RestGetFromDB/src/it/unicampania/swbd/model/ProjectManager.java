package it.unicampania.swbd.model;

import java.sql.Connection;
import java.util.ArrayList;

import dto.FeedAuto;
import dto.FeedGuasti;
import dto.FeedID;
import dto.FeedLetture;
import dto.FeedTipo;
import it.unicampania.swbd.dao.Database;

import it.unicampania.swbd.dao.Project;
import it.unicampania.swbd.dao.Project2;
import it.unicampania.swbd.dao.Project3;
import it.unicampania.swbd.dao.Project4GetLetture;
import it.unicampania.swbd.dao.ProjectAssicuratore;
import it.unicampania.swbd.dao.Projectsensori;


public class ProjectManager {
	
	
	public ArrayList<FeedAuto> GetFeeds()throws Exception {
		ArrayList<FeedAuto> feeds = null;
		try {
			    Database database= new Database();
			    Connection connection = database.Get_Connection();
				Project project= new Project();
				feeds=project.GetFeeds(connection);
		
		} catch (Exception e) {
			throw e;
		}
		return feeds;
	}
	
	
	public ArrayList<FeedID> GetFeeds2()throws Exception {
		ArrayList<FeedID> feeds = null;
		try {
			    Database database= new Database();
			    Connection connection = database.Get_Connection();
				Project2 project= new Project2();
				feeds=project.GetFeeds2(connection);
		
		} catch (Exception e) {
			throw e;
		}
		return feeds;
	}
	public void GetFeeds3(FeedLetture nuovoOggetto)throws Exception {
		//ArrayList<FeedLetture> feeds = null; // QUI SI FA LA POST!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		try {
			    Database database= new Database();
			    Connection connection = database.Get_Connection();
				Project3 project= new Project3();
				project.GetFeeds3(connection,nuovoOggetto);
				//feeds=project.GetFeeds3(connection);
		
		} catch (Exception e) {
			throw e;
		}
		
		//return feeds;
	}
	public ArrayList<FeedLetture> GetFeeds4()throws Exception {
		ArrayList<FeedLetture> feeds = null;
		try {
			    Database database= new Database();// QUI SI FA LA GET LETTURE !!!!!!!!!!!!!!!!!!
			    Connection connection = database.Get_Connection();
				Project4GetLetture project= new Project4GetLetture();
				feeds=project.GetFeeds4(connection);
		
		} catch (Exception e) {
			throw e;
		}
		return feeds;
	}
	public ArrayList<FeedGuasti> GetFeeds5()throws Exception {
		ArrayList<FeedGuasti> feeds = null;
		try {
			    Database database= new Database();
			    Connection connection = database.Get_Connection();
				ProjectAssicuratore project= new ProjectAssicuratore();
				feeds=project.GetFeeds5(connection);
		
		} catch (Exception e) {
			throw e;
		}
		return feeds;
	}
	public ArrayList<FeedTipo> GetFeedssensori()throws Exception {
		ArrayList<FeedTipo> feeds = null;
		try {
			    Database database= new Database();
			    Connection connection = database.Get_Connection();
				Projectsensori project= new Projectsensori();
				feeds=project.GetFeedssensori(connection);
		
		} catch (Exception e) {
			throw e;
		}
		return feeds;
	}

}
