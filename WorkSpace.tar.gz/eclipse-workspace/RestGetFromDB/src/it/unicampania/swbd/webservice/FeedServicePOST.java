package it.unicampania.swbd.webservice;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.JSONObject;
import org.json.simple.parser.JSONParser;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

import dto.FeedAuto;
import dto.FeedLetture;
import it.unicampania.swbd.model.ProjectManager;

@Path("/client")
public class FeedServicePOST {
	
	@POST
	@Path("/post")
	@Consumes(MediaType. APPLICATION_JSON)

	public Response myREST (InputStream incomingData) throws Exception 
	{
		ObjectMapper objectMapper1;
		StringBuilder myStringBuilder = null;
		try{	
	 myStringBuilder = new StringBuilder();
	 BufferedReader in=new BufferedReader (new InputStreamReader (incomingData));
	 String line = null;
	 while ((line = in.readLine()) != null)
	 {
	 myStringBuilder.append(line);
	 }
		}
		catch (Exception e)
		 {
		  System.out.println ("Error Parsing : ");
		  
		  }

	 System.out.println ("Data Received: " + myStringBuilder.toString());
	 
	 String stringaJson = myStringBuilder.toString();
	

	
		
		Gson g = new Gson();
		FeedLetture nuovoOggetto = g.fromJson(stringaJson, FeedLetture.class);
		ProjectManager projectManager= new ProjectManager();
		projectManager.GetFeeds3(nuovoOggetto);

		
		
		
	 return Response.status(200).entity(myStringBuilder.toString()).build();
	 
	}

}