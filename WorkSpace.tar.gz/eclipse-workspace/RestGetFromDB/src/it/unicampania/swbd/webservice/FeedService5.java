package it.unicampania.swbd.webservice;

import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import com.fasterxml.jackson.databind.ObjectMapper;

import dto.FeedAuto;
import dto.FeedGuasti;
import it.unicampania.swbd.model.ProjectManager;


	@Path("/WebService")
	public class FeedService5 {
		
		@GET
		@Path("/GetFeeds5")
		@Produces("application/json")
		public String feed()
		{
			String feeds  = null;
			try 
			{
				ArrayList<FeedGuasti> feedData = null;
				ProjectManager projectManager= new ProjectManager();
				feedData = projectManager.GetFeeds5();
	
							
				ObjectMapper mapper = new ObjectMapper(); 
				feeds = mapper.writeValueAsString(feedData);
	
			} catch (Exception e)
			{
				e.printStackTrace();
				System.out.println("error");
			}
			return feeds;
		}
		
		
		
		
	}

