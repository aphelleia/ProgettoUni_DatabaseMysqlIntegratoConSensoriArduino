package it.unicampania.swbd.webservice;

import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import com.fasterxml.jackson.databind.ObjectMapper;



import dto.FeedID;
import it.unicampania.swbd.model.ProjectManager;

@Path("/WebService")
public class FeedService2 {
	
	@GET
	@Path("/GetFeeds2")
	@Produces("application/json")
	public String feed()
	{
		String feeds  = null;
		try 
		{
			ArrayList<FeedID> feedData = null;
			ProjectManager projectManager= new ProjectManager();
			feedData = projectManager.GetFeeds2();
			
			ObjectMapper mapper = new ObjectMapper(); 
			feeds = mapper.writeValueAsString(feedData);
			

		} catch (Exception e)
		{
			e.printStackTrace();
			System.out.println("error");
		}
		return feeds;
	}

}