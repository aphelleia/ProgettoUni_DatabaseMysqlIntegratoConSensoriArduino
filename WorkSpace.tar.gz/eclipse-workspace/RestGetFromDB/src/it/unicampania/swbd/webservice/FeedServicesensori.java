package it.unicampania.swbd.webservice;

import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import com.fasterxml.jackson.databind.ObjectMapper;



import dto.FeedTipo;
import it.unicampania.swbd.model.ProjectManager;

@Path("/WebService")
public class FeedServicesensori {
	
	@GET
	@Path("/GetFeedssensori")
	@Produces("application/json")
	public String feed()
	{
		String feeds  = null;
		try 
		{
			ArrayList<FeedTipo> feedData = null;
			ProjectManager projectManager= new ProjectManager();
			feedData = projectManager.GetFeedssensori();
			//StringBuffer sb = new StringBuffer();
			
			ObjectMapper mapper = new ObjectMapper(); 
			feeds = mapper.writeValueAsString(feedData);
			

		} catch (Exception e)
		{
			e.printStackTrace();
			System.out.println("errorsensori");
		}
		return feeds;
	}

}
