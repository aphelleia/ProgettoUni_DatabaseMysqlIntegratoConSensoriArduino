package it.unicampania.swbd.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Database {
	public Connection Get_Connection() throws Exception
	{
	try
	{
		DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
		String connectionURL = "jdbc:mysql://localhost:3306/Assicurazioni?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=Europe/Rome";
		Connection connection = null;
		connection = DriverManager.getConnection(connectionURL, "stud", "studente");
		return connection;
		
	}
	catch (SQLException e)
	{
	throw e;
	}
	catch (Exception e)
	{
	throw e;
	}
	}

	}
	
	
