package it.unicampania.swbd.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import dto.FeedGuasti;

public class ProjectAssicuratore {
	public ArrayList<FeedGuasti> GetFeeds5(Connection connection) throws Exception
	{
		ArrayList<FeedGuasti> feedData = new ArrayList<FeedGuasti>();
	
		try
		{
			
			PreparedStatement ps = connection.prepareStatement("SELECT * FROM Guasti");
		
		
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
			  FeedGuasti feedObject = new FeedGuasti(rs.getString("ID_Scatolanera"),
			  rs.getString("DataeOra"),rs.getString("Temperatura"), rs.getString("FurtoBenzina"),rs.getString("Distanza"),rs.getString("latitudine"),rs.getString("longitudine"));
			  	
			  feedData.add(feedObject);
			
			}
			
			return feedData;
		}
		catch(Exception e)
		{
			throw e;
		}
	}

}
