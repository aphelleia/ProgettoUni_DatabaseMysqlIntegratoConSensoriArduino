package it.unicampania.swbd.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;



import dto.FeedID;



public class Project2 {
	
	
	public ArrayList<FeedID> GetFeeds2(Connection connection) throws Exception
	{
		ArrayList <FeedID>  feedData = new ArrayList<FeedID>();
		try
		{
			
			PreparedStatement ps = connection.prepareStatement("SELECT * FROM targaScatolaNera");
		
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				FeedID feedObject = new FeedID(rs.getString("ID_Scatolanera"),
						rs.getString("Targa")
						);
				feedData.add(feedObject);
			}
			return feedData;
		}
		catch(Exception e)
		{
			throw e;
		}
	}
		
}
