package it.unicampania.swbd.dao;
import it.unicampania.swbd.webservice.FeedServicePOST;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import dto.FeedLetture;



public class Project4GetLetture {
	
	
	public ArrayList<FeedLetture> GetFeeds4(Connection connection) throws Exception
	{
		ArrayList<FeedLetture> feedData = new ArrayList<FeedLetture>();

		try
		{
			
			PreparedStatement ps = connection.prepareStatement("SELECT * FROM lettureSensoriSecondoLivello ORDER BY N_Record DESC LIMIT 1;");
		
			//ORDER BY N_Record DESC LIMIT 1;
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				      FeedLetture feedObject = new FeedLetture(rs.getString("id_Scatolanera"),
						rs.getString("temperatura"),
						rs.getString("distanza"), 
						rs.getString("statusAntifurto"),
						rs.getString("latitudine"), 
						rs.getString("longitudine") );
					
					feedData.add(feedObject);

			}
			
			return feedData;
		}
		catch(Exception e)
		{
			throw e;
		}
	}
		
}
