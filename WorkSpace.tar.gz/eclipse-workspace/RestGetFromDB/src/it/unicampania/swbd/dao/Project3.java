package it.unicampania.swbd.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;

import it.unicampania.swbd.webservice.FeedServicePOST;
import dto.FeedAuto;
import dto.FeedID;
import dto.FeedLetture;

public class Project3 {
	public void GetFeeds3(Connection connection,FeedLetture nuovoOggetto) throws Exception
	{

		try
		{
		
			String distanzaDaInserire = nuovoOggetto.getdistanza();
			String temperaturaDaInserire = nuovoOggetto.getTemperatura();
			String statusAntifurtoDaInserire = nuovoOggetto.getstatusAntifurto();
	
			Timestamp timestamp = new Timestamp(System.currentTimeMillis());
            System.out.println(timestamp);
 
				PreparedStatement ps = connection.prepareStatement( "SELECT * FROM Guasti" , ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			ResultSet rs = ps.executeQuery();
			rs.moveToInsertRow(); // moves cursor to the insert row
		    rs.updateString("ID_scatolaNera", nuovoOggetto.getID_Scatolanera());
		    rs.updateTimestamp("DataeOra",timestamp);
		    rs.updateString("Temperatura",nuovoOggetto.getTemperatura());
		    rs.updateString("FurtoBenzina", nuovoOggetto.getstatusAntifurto());
		    rs.updateString("Distanza", nuovoOggetto.getdistanza());
		    rs.updateString("latitudine", nuovoOggetto.getlatitudine());
		    rs.updateString("longitudine", nuovoOggetto.getlongitudine());
            rs.insertRow();
		    rs.moveToCurrentRow();
		  
		}
		catch(Exception e)
		{
			throw e;
		}
	}
}
	
		


