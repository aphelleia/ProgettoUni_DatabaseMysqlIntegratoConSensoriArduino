package it.unicampania.swbd.dao;
import it.unicampania.swbd.webservice.FeedServicePOST;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import dto.FeedAuto;



public class Project {
	
	
	public ArrayList<FeedAuto> GetFeeds(Connection connection) throws Exception
	{
		ArrayList<FeedAuto> feedData = new ArrayList<FeedAuto>();
	
		try
		{
			
			PreparedStatement ps = connection.prepareStatement("SELECT * FROM Registro_clienti");
		
		
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				      FeedAuto feedObject = new FeedAuto(rs.getString("targa_auto"),
						rs.getString("nome"),rs.getString("cognome"), rs.getString("classe"),  rs.getString("DataAssicurazione"), rs.getString("DataScadenza") );
				      
					
					feedData.add(feedObject);
			
					
				
			}
			
			return feedData;
		}
		catch(Exception e)
		{
			throw e;
		}
	}
		
}
