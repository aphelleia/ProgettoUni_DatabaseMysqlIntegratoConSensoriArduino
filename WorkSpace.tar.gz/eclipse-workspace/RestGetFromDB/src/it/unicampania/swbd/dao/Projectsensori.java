package it.unicampania.swbd.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;



import dto.FeedTipo;



public class Projectsensori {
	
	
	public ArrayList<FeedTipo> GetFeedssensori(Connection connection) throws Exception
	{
		ArrayList <FeedTipo>  feedData = new ArrayList<FeedTipo>();
		try
		{
			
			PreparedStatement ps = connection.prepareStatement("SELECT * FROM sensoriPrimoLivello ");
		
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				FeedTipo feedObject = new FeedTipo(rs.getString("ID"),
						rs.getString("ID_Scatolanera"), rs.getNString("Tipo")
						);
				feedData.add(feedObject);
			}
			return feedData;
		}
		catch(Exception e)
		{
			throw e;
		}
	}
		
}
