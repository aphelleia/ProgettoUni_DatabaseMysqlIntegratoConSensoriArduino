package dto;
import java.sql.*;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class generatoreRecordNelDb {

	public void generaValoriCasuali() {
		
		Connection conn = null;
		
		String punto = ".";
		

		// QUI VENGONO GENERATi TUTTI I DATI NECESSARI PER IL RIEMPIMENTO AUTOMATICO DELLA TABELLA lettureSecondoLivello 
		
		int ID_Scatolanera = ThreadLocalRandom.current().nextInt(1, 5 + 1);
		int temperatura = ThreadLocalRandom.current().nextInt(0, 150 + 1);
		int benzina = ThreadLocalRandom.current().nextInt(0, 99 + 1);
		int distanza = ThreadLocalRandom.current().nextInt(0, 10 + 1);
		int statusAntifurto = ThreadLocalRandom.current().nextInt(0, 1 + 1);
		int statusVeicolo = ThreadLocalRandom.current().nextInt(1, 1 + 1);
		int statusFari = ThreadLocalRandom.current().nextInt(0, 1 + 1);
		int velocitaDiParcheggio = ThreadLocalRandom.current().nextInt(0, 5 + 1);
		

		// QUI VENGONO GENERATE LE COORDINATE GPS, PER CONOSCERE LA POSIZIONE BISOGNA INSERIRLE NEL GOOGLE MAPS
				
		
		int latitudine = 40;
		int minutiLatitudine = ThreadLocalRandom.current().nextInt(30, 99 + 1);
		int secondiLatitudine = ThreadLocalRandom.current().nextInt(0, 99 + 1);
        int a = Integer.parseInt(Integer.toString(minutiLatitudine) + Integer.toString(secondiLatitudine));
        double  coordinataVerticale = Double.parseDouble(latitudine + "." + a);
     
  
		int longitudine = 14;
		int minutiLongitudine = 99;
		int secondiLongitudine = ThreadLocalRandom.current().nextInt(0, 99 + 1);
        int b = Integer.parseInt(Integer.toString(minutiLongitudine) + Integer.toString(secondiLongitudine));
        double coordinataOrizzontale = Double.parseDouble(longitudine + "." + b);

        try { 
		        	try
		        	{
		        	Class.forName("com.mysql.cj.jdbc.Driver");
		        	
		        	conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Assicurazioni?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=Europe/Rome","stud", "studente");
		        	System.out.print("Database is connected !");
		        	
		        	}
		        	catch(Exception e)
		        	{
		        	System.out.print("Do not connect to DB - Error:"+e);
		        	}
	
		            
		            PreparedStatement pstmt = conn.prepareStatement("INSERT INTO `lettureSensoriSecondoLivello`(`ID_ScatolaNera`, `Temperatura`, `statusVeicolo`, `statusFari`, `benzina`, `distanza`, `velocitaDiParcheggio`, `statusAntifurto`, `latitudine`, `longitudine`) VALUE (?,?,?,?,?,?,?,?,?,?)");
		            pstmt.setInt(1, ID_Scatolanera );
		            pstmt.setInt(2, temperatura);
		            pstmt.setInt(3, statusVeicolo);
		            pstmt.setInt(4, statusFari);
		            pstmt.setInt(5,benzina);
		            pstmt.setInt(6, distanza);
		            pstmt.setInt(7, velocitaDiParcheggio);
		            pstmt.setInt(8, statusAntifurto);
		            pstmt.setDouble(9,coordinataVerticale);
		            pstmt.setDouble(10,coordinataOrizzontale);
		            
		            pstmt.executeUpdate();
		            
		          
		            //System.out.print("stampa sul db eseguita");
		            conn.close(); 
		        } catch (Exception e) { 
		            System.err.println("Got an exception! "); 
		            System.err.println(e.getMessage()); 
		        } 
	

	}

}
