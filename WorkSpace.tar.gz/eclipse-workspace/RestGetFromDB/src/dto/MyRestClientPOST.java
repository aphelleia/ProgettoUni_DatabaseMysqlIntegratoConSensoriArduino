package dto;


import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import com.google.common.reflect.TypeToken;
import java.lang.reflect.Type;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.simple.JSONObject;

import com.google.gson.Gson;


public class MyRestClientPOST {

    String stampa;

    
		public static int POST(FeedLetture oggettoVerifica){
			 String jsonStr = null;
			 String jsonResult = null;
		        
		        try {
		        	ObjectMapper mapper = new ObjectMapper(); 
					jsonResult = mapper.writeValueAsString(oggettoVerifica);
					//System.out.println("stringa formattata con il metodo del prof (jsonResult)" + jsonResult);
					
	            } catch (Exception e) {
	                System.out.println("\nError while creating object mapper");
	                System.out.println(e);
	            }
		        
		    	try {
		    		
		    		

					URL url = new URL(
							"http://localhost:8080/RestGetFromDB/client/post/");
					HttpURLConnection conn = (HttpURLConnection) url.openConnection();
					conn.setDoOutput(true);
					conn.setRequestMethod("POST");
					conn.setRequestProperty("Content-Type", "application/json");


					OutputStream os = conn.getOutputStream();
					os.write(jsonResult.getBytes());
					os.flush();

					/*if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
						throw new RuntimeException("Failed : HTTP error code : "
								+ conn.getResponseCode());
					}*/

					BufferedReader br = new BufferedReader(new InputStreamReader(
							(conn.getInputStream())));

					String output;
					System.out.println("Output from Server .... \n");
					while ((output = br.readLine()) != null) {

						System.out.println(output);
					}

					conn.disconnect();

				} catch (MalformedURLException e) {

					e.printStackTrace();
				} catch (IOException e) {

					e.printStackTrace();

				}
			         return 1;
			    }
			        
		}
	
    
