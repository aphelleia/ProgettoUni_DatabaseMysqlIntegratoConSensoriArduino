package dto;

public class FeedID {


	private String Targa;
	private String ID_Scatolanera;
	

	
	public FeedID (String v, String k) {
		Targa=k;
		ID_Scatolanera=v; 
		
	}
	
	public String getTarga() {
		return Targa;
	}
	public void setTarga(String Targa) {
		this.Targa= Targa;
	}
	public String getID_Scatolanera() {
		return ID_Scatolanera;
	}
	public void setID_Scatolanera(String ID_Scatolanera)
	{this.ID_Scatolanera= ID_Scatolanera;
	}
	
	
	
	


}
