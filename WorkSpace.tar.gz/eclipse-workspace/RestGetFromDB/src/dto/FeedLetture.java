package dto;

public class FeedLetture {
	private String id_Scatolanera; 
	private String temperatura; 
	private String distanza; 
	private String statusAntifurto;
	private String latitudine; 
	private String longitudine; 

	

	
	public FeedLetture (String i, String t, String d , String e, String l , String m) {
		id_Scatolanera=i;
		temperatura=t;  
		distanza = d;
		statusAntifurto = e;
		latitudine= l;
		longitudine = m;
		
	}
	
	public FeedLetture() {
		// TODO Auto-generated constructor stub
	}

	public String getID_Scatolanera() {
		return id_Scatolanera;
	}
	public void setID_Scatolanera(String ID_Scatolanera) {
		this.id_Scatolanera = ID_Scatolanera;
	}
	public String getTemperatura() {
		return temperatura;
	}
	public void setTemperatura(String Temperatura) {
		this.temperatura = Temperatura;
	}
	public String getstatusAntifurto() {
		return statusAntifurto;
	}
	public void setstatusAntifurto(String statusAntifurto) {
		this.statusAntifurto = statusAntifurto;
	}
	public String getdistanza() {
		return distanza;
	}
	public void setdistanza(String distanza) {
		this.distanza= distanza;
	}
	public String getlatitudine() {
		return latitudine;
	}
	public void setlatitudine(String latitudine) {
		this.latitudine = latitudine;
	}
	public String getlongitudine() {
		return longitudine;
	}
	public void setlongitudine(String longitudine) {
		this.longitudine= longitudine;
	}

	
	public String controlloTemperatura(String parametroPassato) {
		// TODO Auto-generated method stub
		int Temperatura=0;
		try {
		   Temperatura = Integer.parseInt(parametroPassato);
		}
		catch (NumberFormatException e)
		{
		   
		}
		 if (Temperatura >= 100) {
			    
			    String stringaDaScrivere = Integer.toString(Temperatura);
	        	this.temperatura = stringaDaScrivere;
	        	return stringaDaScrivere;
	        }else {
	        	this.temperatura = null;
		        return this.temperatura;}
		
	}
	
	
	
	public String controlloDistanza(String parametroPassato) {
		// TODO Auto-generated method stub
		int distanza=0;
		
	distanza = Integer.parseInt(parametroPassato);
		
		    
		
		 if (distanza == 0) {
			    
		
			    String stringaDaScrivere = Integer.toString(distanza);
	       
	        	return stringaDaScrivere;
	        }else {
	        	this.distanza = null;
		        return null;}
		
	}
	
	
	
	public String controlloAntifurto(String parametroPassato) {
		// TODO Auto-generated method stub
		int statusAntifurto=0;
		try {
		   statusAntifurto = Integer.parseInt(parametroPassato);
		}
		catch (NumberFormatException e)
		{
		   
		}
		 if (statusAntifurto==1)
			  
		 {
			  
			    String stringaDaScrivere = Integer.toString(statusAntifurto);
	      
	        	return stringaDaScrivere;
	        }else {
	        	this.statusAntifurto=null;
		 return null;}
		
	}
	
	

}
