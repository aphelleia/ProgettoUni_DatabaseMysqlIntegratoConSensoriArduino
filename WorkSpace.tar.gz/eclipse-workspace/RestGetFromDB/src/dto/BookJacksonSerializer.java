package dto;

import java.io.IOException;
import java.text.SimpleDateFormat;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;


public class BookJacksonSerializer extends StdSerializer<FeedLetture > {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
	
	protected BookJacksonSerializer(Class<FeedLetture> src) {
		super(src);
		
	}

	@Override
	public void serialize(FeedLetture value, JsonGenerator gen, SerializerProvider provider) throws IOException {
		
	    
	    gen.writeStartObject();
        gen.writeStringField("id_Scatolanera", value.getID_Scatolanera());
        gen.writeStringField("temperatura", value.getTemperatura());
        gen.writeStringField("statusAntifurto", value.getstatusAntifurto());
        gen.writeStringField("distanza", value.getdistanza());
        gen.writeStringField("latitudine", value.getlatitudine());
        gen.writeStringField("longitudine", value.getlongitudine());
        
        
    
	
	}



}


