package dto;
import dto.FeedLetture;


import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import com.google.common.reflect.TypeToken;
import java.lang.reflect.Type;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.simple.JSONObject;

import com.google.gson.Gson;


public class MyRestClient {

 
    
   

    
		public static void main(String[] args) throws InterruptedException {
			   String stampa;
			
		       while(true){
		    	   generatoreRecordNelDb genera = new generatoreRecordNelDb();
		    	   genera.generaValoriCasuali();
		    	   
		    	   
		    	   String myURL = "http://localhost:8080/RestGetFromDB/WebService/GetFeeds3/";
		            MyRestClient object = new MyRestClient();
		    	//	object.waitMethod(myURL);
		    	
    			System.out.println("Requested URL: " + (myURL));
    			StringBuilder sb = new StringBuilder();
    			URLConnection urlConn = null;
    			InputStreamReader in = null;
    			try {
    				URL url = new URL(myURL);
    				urlConn = url.openConnection();
    				if (urlConn != null)
    					//urlConn.setReadTimeout(60 * 1000);
    				if (urlConn != null && urlConn.getInputStream() != null) {
    					in = new InputStreamReader(urlConn.getInputStream(), Charset.defaultCharset());
    					BufferedReader bufferedReader = new BufferedReader(in);
    					if (bufferedReader != null) {
    						int cp;
    						while ((cp = bufferedReader.read()) != -1) {
    							sb.append((char) cp);
    						}
    						bufferedReader.close();
    					}
    				}
    			
    				in.close();
    			
    			} catch (Exception e) {
    				throw new RuntimeException("Exception while calling URL:" + myURL, e);
    			}
    	 
    			stampa = sb.toString();
  
    			
    			ObjectMapper objectMapper1 = new ObjectMapper();
    			ObjectMapper objectMapper2 = new ObjectMapper();

    			FeedLetture[] car1;
    			FeedLetture[] car2;
    			 FeedLetture oggettoVerifica = new FeedLetture ();
    			 FeedLetture oggettoInvariato = new FeedLetture ();
    			 
    			 JSONObject stringaJson = new JSONObject();
    			 String jsonStr = null;
    			 String jsonResult = null;
    			// System.out.println(stampa);

    			try {
    			    car1 = objectMapper1.readValue(stampa, FeedLetture[].class);
    			    car2 = objectMapper2.readValue(stampa, FeedLetture[].class);

        			oggettoVerifica = car1[0];
        			oggettoInvariato = car2[0];
        			
    			} catch (IOException e) {
    			    e.printStackTrace();
    			}
    			
    			
			    String temperatura = oggettoVerifica.getTemperatura();
	
			    temperatura = oggettoVerifica.controlloTemperatura(temperatura);   
			    temperatura = oggettoVerifica.getTemperatura();
			    String statusAntifurto = oggettoVerifica.getstatusAntifurto();
			    statusAntifurto = oggettoVerifica.controlloAntifurto(statusAntifurto);
			    String distanza = oggettoVerifica.getdistanza();
			   
			    distanza = oggettoVerifica.controlloDistanza(distanza);
		
			    if (temperatura==null&&statusAntifurto==null&&distanza==null)
			    {
			    	
			    }
			    else {
			    	//System.out.println("Sono pronto per fare la insert al database con temperatura ecc");
			    	int successo = MyRestClientPOST.POST(oggettoVerifica);
			    	System.out.println(successo);
			    	}
			
			    Thread.sleep(10000);
		       }
}
}
