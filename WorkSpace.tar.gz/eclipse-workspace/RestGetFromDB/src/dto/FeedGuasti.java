package dto;

public class FeedGuasti {
	private String ID_Scatolanera; 
	private String DataeOra; 
	private String Temperatura;
	private String FurtoBenzina;
	private String Distanza;
	private String latitudine;
	private String longitudine;
	

	

    public FeedGuasti (String i, String t, String d , String e, String f,String p, String s) {
		ID_Scatolanera=i;
		DataeOra=t; 
		Temperatura = d; 
		FurtoBenzina = e;
		Distanza = f;
		latitudine = p;
		longitudine = s;
		
		
	}

	public String getID_Scatolanera() {
		return ID_Scatolanera;
	}
	public void setID_Scatolanera(String ID_Scatolanera) {
		this.ID_Scatolanera = ID_Scatolanera;
	}
	public String getDataeOra() {
		return DataeOra;
	}
	public void setDataeOra(String DataeOra) {
		this.DataeOra = DataeOra;
	}
	public String getTemperatura() {
		return Temperatura;
	}
	public void setTemperatura(String Temperatura) {
		this.Temperatura = Temperatura;
	}
	public String getFurtoBenzina() {
		return FurtoBenzina;
	}
	public void setFurtoBenzina(String FurtoBenzina) {
		this.FurtoBenzina = FurtoBenzina;
	}
	public String getDistanza() {
		return Distanza;
	}
	public void setDistanza(String Distanza) {
		this.Distanza = Distanza;
	}
	public String getlatitudine() {
		return latitudine;
	}
	public void setlatitudine(String latitudine) {
		this.latitudine = latitudine;
	}
	public String getlongitudine() {
		return longitudine;
	}
	public void setlongitudine(String longitudine) {
		this.longitudine = longitudine;
	}
	
}
