package dto;

public class FeedTipo {


	private String ID;
	private String ID_Scatolanera;
	private String Tipo;
	

	
	public FeedTipo (String v, String k, String n) {
		ID=k;
		ID_Scatolanera=v;
		Tipo=n;
		
	}
	
	public String getID() {
		return ID;
	}
	public void setID(String ID) {
		this.ID= ID;
	}
	public String getID_Scatolanera() {
		return ID_Scatolanera;
	}
	public void setID_Scatolanera(String ID_Scatolanera)
	{this.ID_Scatolanera= ID_Scatolanera;
	}
	public String getTipo() {
		return Tipo;
	}
	public void setTipo(String Tipo) {
		this.Tipo= Tipo;
	}
}