package dto;

public class FeedAuto {


	private String targa_auto; 
	private String nome; 
	private String cognome;
	private String classe;
	private String DataAssicurazione;
	private String DataScadenza;

	
	  //default constructor
    public FeedAuto()
    {
     super();
    }
    public FeedAuto (String i, String t, String d , String e, String f, String p) {
		targa_auto=i;
		nome=t; 
		cognome = d; 
		classe = e;
		DataAssicurazione = f;
		DataScadenza = p;
		
	}

	public String gettarga_auto() {
		return targa_auto;
	}
	public void settarga_auto(String targa_auto) {
		this.targa_auto = targa_auto;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCognome() {
		return cognome;
	}
	public void setReleaseDate(String desc) {
		this.cognome = desc;
	}
	public String getclasse() {
		return classe;
	}
	public void setclasse(String classe) {
		this.classe = classe;
	}
	public String getDataAssicurazione() {
		return DataAssicurazione;
	}
	public void setDataAssicurazione(String dataDaSettare) {
		this.DataAssicurazione = dataDaSettare;
	}
	public String getDataScadenza() {
		return DataScadenza;
	}
	public void setDataScadenza(String dataDaSettare) {
		this.DataScadenza = dataDaSettare;
	}
	public String controlloClasse(String parametroPassato) {
		// TODO Auto-generated method stub
		int foo;
		try {
		   foo = Integer.parseInt(parametroPassato);
		}
		catch (NumberFormatException e)
		{
		   foo = 0;
		}
		 if (foo == 10) {
			    foo = 15;
			    String stringaDaScrivere = Integer.toString(foo);
	        	this.classe = stringaDaScrivere;
	        	return stringaDaScrivere;
	        }else {
		 return parametroPassato;}
		
	}
	


}
